package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.apache.tomcat.util.buf.HexUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}


@RestController
class ServerContoller {
	@RequestMapping("/hash")
	public String myHash() throws NoSuchAlgorithmException {
		
		String data = "Good day, Scott Weiss.";
		MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
		//Reference: MessageDigest (Java Platform SE 8 ). (2025, October 20). https://docs.oracle.com/javase/8/docs/api/java/security/MessageDigest.html
		
		byte[] byteArray = messageDigest.digest(data.getBytes());
		//Reference: String (Java Platform SE 8 ). (2025, October 20). https://docs.oracle.com/javase/8/docs/api/java/lang/String.html
		
		String checksum = HexUtils.toHexString(byteArray);
		//Reference: HexUtils (Apache Tomcat 10.1.49 API Documentation). (n.d.). https://tomcat.apache.org/tomcat-10.1-doc/api/org/apache/tomcat/util/buf/HexUtils.html
		
		return "<p>data: " + data + "</p>" + "<p>SHA-256 : Checksum value: " + checksum + "</p>";
	}
}
